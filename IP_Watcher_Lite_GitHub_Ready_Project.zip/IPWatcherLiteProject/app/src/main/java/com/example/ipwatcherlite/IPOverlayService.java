package com.example.ipwatcherlite;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.net.NetworkInterface;
import java.util.Collections;

public class IPOverlayService extends Service {
    private WindowManager windowManager;
    private View overlayView;
    private TextView ipText;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null);
        ipText = overlayView.findViewById(R.id.ip_text);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 100;
        params.y = 100;

        windowManager.addView(overlayView, params);

        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        cm.registerNetworkCallback(
            new NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(),
            new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    runOnUiThread(() -> ipText.setText(getMobileIPv4()));
                }
            }
        );
    }

    private void runOnUiThread(Runnable action) {
        new android.os.Handler(getMainLooper()).post(action);
    }

    private String getMobileIPv4() {
        try {
            for (NetworkInterface intf : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (java.net.InetAddress addr : Collections.list(intf.getInetAddresses())) {
                    if (!addr.isLoopbackAddress() && addr instanceof java.net.Inet4Address) {
                        if (intf.getName().contains("rmnet") || intf.getName().contains("ccmni") || intf.getName().contains("tun")) {
                            return addr.getHostAddress();
                        }
                    }
                }
            }
        } catch (Exception ex) {}
        return "No IPv4";
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (overlayView != null) windowManager.removeView(overlayView);
        super.onDestroy();
    }
}